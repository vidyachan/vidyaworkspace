package JavaMarketingAssignments;

import java.util.Scanner;

public class GPSeries {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		float a,r,i,tn;
		int n;
		float sum=0;
		System.out.print("Enter 1st Number in GPSeries:");
		a=sc.nextFloat();
		System.out.print("Enter Total numbers in tne series:");
		n=sc.nextInt();
		System.out.print("Enter common ratio in tne series:");
		r=sc.nextFloat();
		sum=(float)((a*(1-Math.pow(r, n+1)))/(1-r));
		tn=(float)(a*(1-Math.pow(r,n-1)));
		System.out.println("tn term of GP:" +tn);
		System.out.println("SUM OF THE GP" +sum);
	}
}
		
		


		
