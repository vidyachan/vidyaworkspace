package JavaMarketingAssignments;

import java.util.Scanner;

public class Hpseries {

	public static void main(String[] args)
	{
		
		Scanner sc=new Scanner(System.in);
		int n;
		float sum,t;
		System.out.println("1+1/2+1/3+......+1/n");
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		sum=0;
		for(float i=1;i<=n;i++)
		{
			t=1/i;
			sum=sum+t;
		}
		System.out.println("Sum of the Series" +sum); 
	}
}
		 
		 

