package JavaMarketingAssignments;
import java.lang.*;
public class SwapArray {

	
	public static void main(String[] args) {
		
		int a[]={1,2,3};
		int b[]={4,5,6};
		int temp[] ={0,0,0};
		System.out.print("FIRST ARRAY: ");
		for(int i=0;i<3;i++)
		{
		System.out.print(" "+a[i]);	
		}
		System.out.println("  ...");
		System.out.print("SECOND ARRAY: ");
		for(int i=0;i<3;i++)
		{
		System.out.print(" "+b[i]);	
		}
		for(int i=0;i<3;i++)
		{
		temp[i]=a[i];
		a[i]=b[i];
		b[i]=temp[i];
		}
		System.out.println("  ...");
		System.out.print("FIRST ARRAY: ");
		for(int i=0;i<3;i++)
		{
		System.out.print(" " +a[i]);	
		}
		System.out.println("  ...");
		System.out.print("SECOND ARRAY: ");
		for(int i=0;i<3;i++)
		{
		System.out.print(" "+b[i]);	
		}


	}

}
