package JavaMarketingAssignments;

import java.util.Scanner;

public class Apseries {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int a,d,n,tn;
		int sum=0;
		System.out.print("Enter 1st Number:");
			a=sc.nextInt();
			System.out.print("Enter Total numbers in tne series:");
			n=sc.nextInt();
			System.out.print("Enter common difference in tne series:");
			d=sc.nextInt();
			sum=(n*(2*a+(n-1)*d))/2;
			tn=a+(n-1)*d;
			System.out.print("Sum of the AP Series");
			for(int i=a;i<=tn;i=i+d)
			{
				if(i != tn)
				{System.out.print(i + " + ");}
				else{System.out.print(i + "=" +sum + " ");}
				
				
				}
			}
	}
	



