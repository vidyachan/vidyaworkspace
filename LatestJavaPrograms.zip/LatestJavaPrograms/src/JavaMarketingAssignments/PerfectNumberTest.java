package JavaMarketingAssignments;
import java.util.Scanner;

public class PerfectNumberTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int i,sum=1;  
		
		 Scanner in=new Scanner(System.in);
		 System.out.print("Enter a Number:...");
         int n=in.nextInt();

        

sum=1;

             for(i=2;i<n;i++)

             {     if(n%i==0)

                   sum=sum+i;

             }

         if(sum==n)

                   System.out.print(i +"   is a perfect number");
         else
         
        	 System.out.println("This is not a perfect number");
        
	}

}
