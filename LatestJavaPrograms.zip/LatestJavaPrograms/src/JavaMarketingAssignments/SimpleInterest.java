package JavaMarketingAssignments;

import java.util.Scanner;

public class SimpleInterest {

	public static void main(String[] args) {
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Principle amount:");
		int amount=sc.nextInt();
		System.out.println("Enter interest rate:");
		int rate=sc.nextInt();
		System.out.println("No of Years:");
		int years=sc.nextInt();
		float si= amount*(1+(rate*years));
		System.out.println("SimpleInterest"+ si);
		
		
		

	}

}
