package JavaMarketingAssignments;

import java.util.Scanner;

public class SumofDigits {

	public static void main(String[] args) {
		int num,r,sum=0;
		System.out.println("Enter a number::");
		Scanner sc = new Scanner(System.in);
		 num=sc.nextInt();
		while(num>10)
		{  sum=0;
		 while(num!=0)
		 {
			r=num%10;
			num=num/10;
			sum=sum+r;
		 }
		
			
		}
		System.out.println("Sum of the Digits of the Number::   " +sum);
	}



	}


