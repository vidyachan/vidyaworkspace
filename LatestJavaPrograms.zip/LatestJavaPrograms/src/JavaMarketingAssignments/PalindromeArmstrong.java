package JavaMarketingAssignments;

import java.util.Scanner;

public class PalindromeArmstrong {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		PalindromeArmstrong ob=new PalindromeArmstrong();
		//ob.palindrome();
		ob.Armstrong();
		
		
	}
	public void Armstrong()
	{
		System.out.println("Enter a number");
		Scanner sc =new Scanner(System.in);
		int i=sc.nextInt();
		int num=i;
        int reversenum;
        int cube=0;
        while(i>0)
		{
			reversenum=i%10;
			i=i/10;
			 cube=cube+(reversenum*reversenum*reversenum);
			
						
		}
        System.out.print(cube);
        
       if(num==cube)
    	   System.out.print("Armstrong Number");
       else
    	   
    	   System.out.print("Not Armstrong Number"); 
		
	}
		
		public void palindrome(){
		System.out.println("Enter a number");
		Scanner sc =new Scanner(System.in);
		int i=sc.nextInt();
		int num=i;
           int reversenum=0;
      do
		{
			reversenum=num%10;
			num=num/10;
			System.out.print(reversenum);
			
		}while(num>0);
		

	}
}

