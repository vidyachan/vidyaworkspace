package JavaMarketingAssignments;

import java.util.Scanner;

public class GenericRoot {

	public static void main(String[] args) {
		
		int num,r,sum=0;
		System.out.println("Enter a number::");
		Scanner sc = new Scanner(System.in);
		 num=sc.nextInt();
		while(num>10)
		{  sum=0;
		 while(num!=0)
		 {
			r=num%10;
			num=num/10;
			sum=sum+r;
		 }
		 if(sum>10)
			num=sum;
		 else
			 break;
			
			
		}
		System.out.println("Generic root of the Number::   " +sum);
	}

}
