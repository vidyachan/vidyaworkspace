package JavaMarketingAssignments;

import java.util.Scanner;

public class Primenumbers {

	public static void main(String[] args) {
		int n;
		int i;
		int num=0;
		int count=0;
		String primenumber=" ";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		n=sc.nextInt();
		for( i=1;i<n;i++)
		{
			for(num=i;num>=1;num--)
				{
				if(i%num==0)
					count=count+1;
				
		     if(count==2)
		
		     primenumber = primenumber + i +" ";
		}
		}
		System.out.println("done");
			System.out.println(" "+primenumber);
		
	}

}
