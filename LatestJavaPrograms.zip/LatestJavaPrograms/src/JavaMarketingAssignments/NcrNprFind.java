package JavaMarketingAssignments;

import java.util.Scanner;

public class NcrNprFind {

	public static void main(String[] args) {
		
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter n value:..");
		int n=sc1.nextInt();
		Scanner sc2 = new Scanner(System.in);
		System.out.println("Enter n value:..");
		int r=sc2.nextInt();
		System.out.println("NCR Value:: "+(fact(n)/(fact(n-r))));
		

	}
	public static int fact(int num)
	{int temp=1;
		
		for(int i=1;i<=num;i++)
		{
			temp=temp*i;
		}
		return temp;
	}

}
