package JavaMarketingAssignments;

public class BitwiseAnd {

	public static void main(String[] args) {
		int x=1;
		int y=2;
		while(y!=0)
		{
		int c=x&y;
		x=x^y;
		y=c<<1;
		}
		System.out.println("Sum of the Numbers::" +x);

	}

}
